function update(id, user, request) {
        console.log('Invoking update script');        
	request.respond();
}
