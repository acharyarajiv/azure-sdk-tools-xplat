function processFeedback() {
    console.log('Logged from feedback!');
}